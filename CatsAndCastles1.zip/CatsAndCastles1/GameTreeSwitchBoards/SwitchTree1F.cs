using CatsAndCastles1.Characters;
using CatsAndCastles1.LocationClasses;
using CatsAndCastles1.Text.Locations;
using CatsAndCastles1.UserInteractions;

namespace CatsAndCastles1.GameTreeSwitchBoards;


public class SwitchTree1F
{
    public void FirstFloorSwitchBoard(Inventory inventory, Hero cat, BadGuy warden)
    {
        warden.Flee = BadGuy.Outcome.Default;
        warden.Bribe = BadGuy.Outcome.Default;

        if (cat.ReturningTo1F) Screen.Print(Text1F.ReturnTo1F);
        else if (warden.Health != 0) Screen.Print(Text1F.Reach1FWardenIsAlive);

        if (warden.Health != 0) 
        {
            SwitchTreeGuard.GuardEncounterSwitchboard(cat, warden, inventory);
            if (warden.Health == 0)
            {
                //instances3F.ThirdFloor.OptionsAtLocation.Insert(4, TextGuard.GuardsDeadBody);
                //instances3F.Guard1Corpse.LocationMethod(inventory);
            }
            if (cat.Location == Hero.Place.SecondFloor) return;
        }
        
        
        
        
        //Lay out:
        //arrive on floor (give intro or return intro)
        //fight guard if he's not dead
        //describe room
        // give option to loot body, move towards door or return upstairs
        // do action
        //somehow change returningTo1F to true if you leave the floor
    }
}