﻿namespace CatsAndCastles1;

class Program
{
    public static void Main(string[] args)
    {
        MainStory mainStory = new MainStory();
        mainStory.RunGame();
    }
}