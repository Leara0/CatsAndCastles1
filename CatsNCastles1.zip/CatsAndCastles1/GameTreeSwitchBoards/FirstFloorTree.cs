using CatsAndCastles1.Characters;
using CatsAndCastles1.LocationClasses;
using CatsAndCastles1.UserInteractions;

namespace CatsAndCastles1.GameTreeSwitchBoards;


public class FirstFloorTree
{
    public void FirstFloorSwitchBoard(Hero cat)
    {
        cat.SuccessfulBribed = false;
    }
}